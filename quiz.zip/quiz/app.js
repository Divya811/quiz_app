var app = angular.module('qApp', []);

var store=[];

app.directive('quiz', function(qfact) {

	return {
		restrict: 'AE',
		scope: {},
		templateUrl: 'template.html',
		link: function(scope, elem, attrs) {
			scope.click1 = function() {
				scope.id = 0;
				scope.over = false;
				scope.progress = true;
				scope.getQuestion();
			};

			scope.reset = function() {
				scope.progress = false;
				scope.score = 0;
			}
var q, selAns;
scope.model ={}

			scope.getQuestion = function() {

				q = qfact.getQuestion(scope.id);
				if(q) {
					scope.question = q.question;
					scope.options = q.options;
					
					scope.answer = q.answer;
					scope.type = q.type;
					scope.num = q.num;
					
			
					
					scope.answerMode = true;
				} else {
					scope.over = true;
				}
			};

						scope.prev = function() {
							if(scope.id != 0) {
							scope.id--;
							scope.getQuestion();
							console.log(store[scope.id])
                            var selectedval = store[scope.id]
						//	scope.selectedAns = store.length !==0 ?  selectedval: " ";
							selAns = store.length !==0 ?  selectedval: " ";
							
					}
					}
			scope.checkAnswer = function() {

					
				if(!$('input[name=answer]:checked').length) return;
				console.log(scope.model)
			
						var ans = scope.model[scope.id];
						//console.log(ans)
						store[scope.id] = scope.model[scope.id]; 
				

					console.log("strore"+store);
					
				if(ans == scope.options[scope.answer]) {
					scope.score++;
					scope.correctAns = true;

					

				} else {
					scope.correctAns = false;
				}

				scope.answerMode = false;
				scope.setques = ans;

				//var ss = {ans};

				
				//var n = q.num;

				
			};
			scope.check = function(option) {
				return selAns!== undefined && option.text === selAns.text ? true : false;



			}
			scope.nextQuestion = function() {
					scope.id++;
				scope.getQuestion();
				if(store[scope.id] !== undefined){
						var selectedvalw = store[scope.id]
				selAns = store.length !==0 ?  selectedvalw: " ";
				}
			
						
			}
			
			scope.reset();

			 
		}
	}
});

app.factory('qfact', function() {
	var questions = [
		{
			num: 1,
         question: "Which of the following selector matches a element based on its id?",
          type: "radio", 

          options: [{
			 text: "The Id Selector",
			 "key": 0
        }
        , {
			 text: "The Universal Selector",
			 "key": 0
        }
        , {
			 text: "The Descendant Selector" ,
			 "key": 0
        }
        , {
			 text: "The Class Selector" ,
			 "key": 0
        }
        ] ,
        answer: 0
    },
		{
		num: 2,
         question: "Which of the following defines a measurement as a percentage relative to another value, typically an enclosing element?",
          type: "checkbox",
           options: [{
			 text: "%" ,
			 key: "opt2"
        }
        , {
			 text: "cm" ,
			 key: "opt5"
        }
        , {
			 text: "percentage" ,
			 key: "opt6"
        }
        , {
			 text: "ex" ,
			 key: "opt7"
        }
        ],
        answer: 2
    },{
    	num: 3,
		question: "Which of the following property is used to set the background color of an element?", 
         type: "radio",
          options: [{
			 text: "background-color" ,
			 key: 2
        }
        , {
			 text: "background-image" ,
			 key: 2
        }
        , {
			 text: "background-repeat" ,
			 key: 2
        }
        , {
			 text: "background-position" ,
			 key: 2
        }
        ] ,
        answer: 0
    },
		{
		num: 4,
         question: "Which of the following is a true about CSS style overriding?",
          type: "checkbox",
           options: [{
			 text: "Any inline style sheet takes highest priority. So, it will override any rule defined in tags or rules defined in any external style sheet file." ,
			 key: 3
        }
        , {
			 text: "Any rule defined in tags will override rules defined in any external style sheet file." ,
			 key: 3
        }
        , {
			 text: "Any rule defined in external style sheet file takes lowest priority, and rules defined in this file will be applied only when above two rules are not applicable." ,
			 key: 3
        }
        ] ,
        answer: 0
    }
	];

	return {
		getQuestion: function(id) {
			if(id < questions.length) {
				return questions[id];
			} else {
				return false;
			}
		}
	};
});
